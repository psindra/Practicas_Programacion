//
//  AppDelegate.h
//  native-xcode
//
//  Created by Jaime Bernardo on 29/09/2017.
//  Copyright © 2017 Janea Systems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

